const Razorpay = require("razorpay");

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method Not Allowed" }) };
  }
  try {
    const { amount, currency = "INR" } = JSON.parse(event.body);
    if (!amount) return { statusCode: 400, body: JSON.stringify({ error: "Amount required" }) };
    const razorpay = new Razorpay({
      key_id: process.env.RAZORPAY_KEY_ID,
      key_secret: process.env.RAZORPAY_KEY_SECRET,
    });
    const order = await razorpay.orders.create({
      amount: amount * 100,
      currency,
      receipt: `rcpt_${Date.now()}`,
    });
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ id: order.id, amount: order.amount, currency: order.currency }),
    };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: "Order failed", details: err.message }) };
  }
};
